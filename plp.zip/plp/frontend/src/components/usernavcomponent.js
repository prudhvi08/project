import React from "react";
import { Link } from "react-router-dom";

export const UserNavComponent = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className ="container-fluid">
         <div className="navbar-header">
          <Link className="navbar-brand" to="/">
          YouJoin
          </Link>
        </div> 

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1">
          <ul className="nav navbar-nav">
            <li>
              <Link class="glyphicon glyphicon-home" to="/usehome">&nbsp;Home</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link to="/mynetwork">My Network</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link  to="/jobs">&nbsp;Jobs</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link  to="/messaging">&nbsp;Messaging</Link>
              <span className="sr-only" />
            </li>
            <li>
              <Link  to="/Example">&nbsp;Example</Link>
              <span className="sr-only" />
            </li>
            {/* <li>
            <Link  to="/usehome">&nbsp;usehome</Link>
              <span className="sr-only" />
            </li> */}
          
         
         
          </ul>

          <ul className="nav navbar-nav navbar-right">

            <li>
              <Link class="glyphicon glyphicon-user" to="/me">&nbsp;Me</Link>
            </li>  
            <li>
            <Link class="glyphicon glyphicon-user" to="/login">&nbsp;LogOut</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default UserNavComponent;

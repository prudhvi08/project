import React, { Component } from 'react'
import axios from 'axios';
import { Redirect } from "react-router";
import { Link } from "react-router-dom";

class Register extends Component {
    constructor(props) {

        super(props);

        this.routeChange =
            this.routeChange.bind(this);

        this.onChangeFirstname =
            this.onChangeFirstname.bind(this);

        this.onChangeLastname =
            this.onChangeLastname.bind(this);

        this.onChangeEmail =
            this.onChangeEmail.bind(this);

        this.onChangePassword =
            this.onChangePassword.bind(this);

        this.onSubmit =
            this.onSubmit.bind(this);

        this.state = {
            Firstname: "",
            Lastname: "",
            Email: "",
            password: "",
            redirect: false
          
        };
    }
    onChangeFirstname(e) {
        this.setState({
            Firstname: e.target.value
        });
    }
    onChangeLastname(e) {
        this.setState({ Lastname: e.target.value });
    }
    onChangeEmail(e) {
        this.setState({ Email: e.target.value });
    }
    onChangePassword(e) {
        this.setState({ password: e.target.value });
    }
    routeChange(id) {
        let path = `/user`;
        this.props.history.push(path);
    }
    onSubmit(e) {
        e.preventDefault();
        const signup = {
            Firstname: this.state.Firstname,
            Lastname: this.state.Lastname,
            Email: this.state.Email,
            password: this.state.password
        };
        console.log(signup);
        axios.post("http://localhost:3001/signup", signup)
            //.then(res => console.log(res.data)); 
            .then(function (response) {
                console.log(response.data);
            });
        this.setState({
            name: "",
            status: "",
            redirect: true
        });
    }
   
    render() {
        const { redirect } = this.state;
        console.log("redirect value" + redirect);
        if (redirect) {
            return <Redirect to="/login" />;
        }
        return (
            <div>
                <h1> Signup </h1>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label> First Name: </label>
                        <input type="text" className="form-control" value={this.state.Firstname}
                            onChange={this.onChangeFirstname} />
                    </div>
                    <div className="form-group">
                        <label> Last Name: </label>
                        <input type="text" className="form-control"
                            value={this.state.Lastname} onChange={this.onChangeLastname} />
                    </div>
                    <div className="form-group">
                        <label> Email :  </label>
                        <input type="email"
                            className="form-control" value={this.state.Email} onChange={this.onChangeEmail} />
                    </div>
                    <div className="form-group">
                        <label> Password: </label>
                        <input type="text"
                            className="form-control" value={this.state.password} onChange={this.onChangePassword} />
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Signup" className="btn btn-primary"  />&nbsp;
                        <input type="submit" value="login" className="btn btn-primary"  />
                    </div>
                   

                </form>
            </div>
        );
    }
}
export default Register
import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';

export class notifications extends Component {
  render() {
    return (
      <div>
           <UserNavComponent/>
          <h1>YOU JOIN</h1>
          
          
      </div>
    )
  }
}

export default notifications

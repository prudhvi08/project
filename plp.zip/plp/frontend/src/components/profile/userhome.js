import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';

export class UserHome extends Component {
  render() {
    return (
      <div>
           <UserNavComponent/>
      
          
          <div
          class="container">

          <div
            class="row">

            <div
              class="col-lg-3">

              <div
                class="card">

                <div
                  class="card-header">

                  <a
                    href="#">

                    <img

                      class="ronded"

                      src="../../assets/usericon.png"

                      align="center"

                      width="200px"

                      height="200px"

                    />

                    <h3
                      align="center">Sai</h3>

                  </a>

                </div>

                <div
                  class="card-body">

                  <font
                    size="2"
                    class="h9 text-muted"

                  >Connections&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a
                      href="#"

                    >50</a

                    > </font

                  ><br />

                  <font
                    size="2"
                    class="h9 text-muted"

                  >Following&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;<a

                      href="#"

                    >50</a

                    >

                  </font>

                </div>

                <div
                  class="card-footer">

                  <font
                    size="2"
                    class="h9 text-muted"

                  >Persons viewed your profile</font

                  >

                  &nbsp;<a
                    href="#">50</a>

                </div>

              </div>

              <br />

              <div
                class="card">

                <div
                  class="card-header">

                  <font
                    size="2"
                    class="h9 text-muted">Recent</font><br
                  />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Capgemini</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Accenture</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Wipro</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Tech Mahindra</a></font

                  ><br /><br />

                  <a
                    href="#">Groups</a><br
                  />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">IT</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">BPO</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Services</a></font

                  ><br />

                  <font
                    size="2.8"
                    class="h9">#
<a
                      href="#">Electronics</a></font

                  ><br />

                </div>

              </div>

            </div>

            <div
              class="col-lg-6">

              <div
                class="card">

                <div
                  class="card-header">

                  <form
                    class="form-group">

                    <textarea

                      type="text"

                      class="form-control"

                      placeholder="Hi Sai Post Here....."

                    ></textarea>

                  </form>

                </div>

                <div
                  class="card-body">

                  <button
                    class="btn btn-outline-dark">Post</button>

                </div>

              </div>

              <br />

              <div
                class="card-body">

                <div
                  class="text-muted h7 mb-2">

                  <i
                    class="fa fa-clock-o"></i>10
                   min ago
                  
</div>

                <a
                  class="card-link"
                  href="#">

                  <h5
                    class="card-title">

                    your Post Title
                    
</h5>

                </a>



                <p
                  class="card-text">

                  your post is here...your post is here...your post is here...your post
                  
                  is here... your post is here...your post is here...your post is
                  
                  here...your post is here...
                  
</p>



                <div
                  class="card-footer">

                  <a
                    href="#"
                    class="card-link"><i
                      class="fa fa-gittip"></i>
                    Like</a>

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-comment"></i>
                    Comment</a

                  >

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-mail-forward"></i>
                    Share</a

                  >

                </div>

              </div>

              <div
                class="card-body">

                <div
                  class="text-muted h7 mb-2">

                  <i  class="fa fa-clock-o"></i>10
                   min ago
                  
</div>

                <a
                  class="card-link"
                  href="#">

                  <h5
                    class="card-title">

                    your Post Title
                    
</h5>

                </a>



                <p
                  class="card-text">

                  your post is here...your post is here...your post is here...your post
                  
                  is here... your post is here...your post is here...your post is
                  
                  here...your post is here...
                  
</p>



                <div
                  class="card-footer">

                  <a
                    href="#"
                    class="card-link"><i
                      class="fa fa-gittip"></i>
                    Like</a>

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-comment"></i>
                    Comment</a

                  >

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-mail-forward"></i>
                    Share</a

                  >

                </div>

              </div>

              <div
                class="card-body">

                <div
                  class="text-muted h7 mb-2">

                  <i
                    class="fa fa-clock-o"></i>10
                   min ago
                  
</div>

                <a
                  class="card-link"
                  href="#">

                  <h5
                    class="card-title">

                    your Post Title
                    
</h5>

                </a>



                <p
                  class="card-text">

                  your post is here...your post is here...your post is here...your post
                  
                  is here... your post is here...your post is here...your post is
                  
                  here...your post is here...
                  
</p>



                <div
                  class="card-footer">

                  <a
                    href="#"
                    class="card-link"><i
                      class="fa fa-gittip"></i>
                    Like</a>

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-comment"></i>
                    Comment</a

                  >

                  <a
                    href="#"
                    class="card-link"

                  ><i
                    class="fa fa-mail-forward"></i>
                    Share</a

                  >

                </div>

              </div>

            </div>

            <div
              class="col-lg-2"></div>

          </div>

          <br />

        </div>




       

      </div>
          
    
    )
  }
}

export default UserHome

const express= require('express');
const mongoose =require('mongoose')
const cors= require('cors');
const morgan=require("morgan");

//database connection
require("./mongo");

//Models
 require("./schema/Post");
 require("./schema/Comment");

 //Middleware 
 app.use(bodyParser.json()).use(morgan());

 //routes
 app.use("/posts",require("./routes/posts"));
 //not found route
 app.use((req,res,next)=>{
     req.status=404;
     const error=new Error("routes not found");
     next(error);

 });

 //error handler

 if(app.get("env")==="production"){
     
 }
import React from 'react';


class like extends React.Component{
    render(){
        return(
            <div>
             
            <h1>User Network</h1>
            </div>
        )
    }
}
export default like;
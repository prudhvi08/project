const mongoose = require('mongoose');
const post_schema = new mongoose.Schema(
    {
        title:{
            type:String,
            required:"title is required"
        },
        content:{
            type:String,
            required:"content is required"
        },
    
    comments: [
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:"Comment",
            required:"Comment is Required Field"
        }
    ]
}
);
//Comments
//Create a Comment
router.post("/:postId/comment",(req,res)=>{
 
    // res.send({ok:true});
})
//read a Comment

module.exports = mongoose.model('Posts', post_schema);
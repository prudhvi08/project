import React, { Component } from "react";
import { BrowserRouter as Router, Switch } from "react-router-dom";
import { Route } from "react-router";
import "./App.css";
import Login from "./components/User component/Login/Login component/Login";
import ProfileDisplay from './components/User component/userProfile/userProfileComponent/ProfileDisplay'
import Registration from "./components/User component/Registration/Registration component/Registration";
// import { library } from '@fortawesome/fontawesome-svg-core';
// import { faEnvelope, faKey } from '@fortawesome/free-solid-svg-icons';
import OrgRegistration from './components/User component/OrgRegistration/OrgRegistration component/OrgRegistration';
import Home from './components/User component/Home/Home component/Home';
import NavComponent from "./components/User component/UserHome/NavbarComponent/NavComponent";
import UserNetwork from "./components/User component/UserHome/UserHomeComponent/UserNetwork";
import Notifications from "./components/User component/UserHome/UserHomeComponent/UserNotification/Notification";
import Cards from "./components/User component/UserHome/UserHomeComponent/UserHome";
import Header from "./components/User component/UserHome/UserHomeComponent/Jobs/Navbar";
import ManageJobs from "./components/User component/UserHome/UserHomeComponent/Jobs/managejobs";
import PostJob from "./components/User component/UserHome/UserHomeComponent/Jobs/postjob";
import ViewJobs from "./components/User component/UserHome/UserHomeComponent/Jobs/viewjobs";
import MyNetwork from "./components/User component/UserHome/UserHomeComponent/UserNetwork/MyNetwork";
import UserProfile from "./components/User component/UserHome/UserHomeComponent/UserProfile/profiledetail";
import AddExperience from "./components/User component/UserHome/UserHomeComponent/UserProfile/addexperience";
import EditProfile from "./components/User component/UserHome/UserHomeComponent/UserProfile/editprofile";
import AddSkill from "./components/User component/UserHome/UserHomeComponent/UserProfile/addskill";
// library.add(faEnvelope, faKey);

class App extends Component {
  render() {
    return (
      <div>
        <Router>
          <Switch>
          <Route exact component={Home} path="/home" />
            <Route component={Login} path="/Login" />
            <Route component={Registration} path="/registration" />
            <Route component={OrgRegistration} path="/register" />
            <Route component={ProfileDisplay} path="/profileDisplay" />
            <Route exact component={NavComponent} path="/" />
            <Route exact component={Cards} path="/userhome"/>
            <Route exact component={MyNetwork} path="/network" />
            <Route exact component={Notifications} path="/notifications"/>
            <Route exact component={Header} path="/Header"/>
            <Route exact component={ManageJobs} path="/managejob"/>
            <Route exact component={PostJob} path="/postjob"/>
            <Route exact component={ViewJobs} path="/viewjobs"/>
            <Route exact component={UserProfile} path="/userprofile"/>
            <Route exact component={AddExperience} path="/addexperience"/>
            <Route exact component={EditProfile} path="/editprofile"/>
            <Route exact component={AddSkill} path="/addskill"/>


          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;

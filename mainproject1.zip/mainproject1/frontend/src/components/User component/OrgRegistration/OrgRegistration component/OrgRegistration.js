import React from 'react';
import images from '../images/down.png';

class OrgRegistration extends React.Component {
    routeChangeGet = (e) => {
        let path = '/login';
        this.props.history.push(path)
    }

    routeChangeHome=(e)=>{
        let path = '/';
        this.props.history.push(path)
    }
       render() {
        return (
            <div style={{ backgroundColor: "brown" }}>
                <br /><br /><br /><br /><br /><br />
                <div className="row justify-content-lg-center">
                    <div className="col-lg-5">
                        <div className="card">
                            <div className="card-body">
                                <center>
                                    <img src={images} width="140px" height="100px" />
                                </center>
                                <h3 align="center">Register Here</h3>
                                <br />
                                <form align="center" onSubmit={this.onSubmit}>
                                <div className=" row justify-content-lg-center">
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <input type="text" className="form-control text-center" placeholder="Enter Name" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <input type="email" className="form-control text-center" placeholder="Enter Email " />
                                            </div>
                                        </div>
                                    </div>

                                    

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">

                                            <div className="form-group">
                                                <input type="number" className="form-control text-center" placeholder="Enter GSTIN" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">


                                            <div className="form-group">
                                                <input type="number" className="form-control text-center" placeholder="Enter PAN" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">

                                            <div className="form-group">
                                                <input type="password" className="form-control text-center" placeholder="Enter MOA" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className=" row justify-content-lg-center">
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <input type="text" className="form-control text-center" placeholder="Enter established year" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <input type="submit" onClick={e => this.routeChangeGet()} value="Sign in" className="btn btn-primary" />&nbsp;
                                        <input type="submit" onClick={e => this.routeChangeHome()} value="Go Back to Home" className="btn btn-success" />

                                    </div>
                                    <h6>Already have an account?&nbsp;

                                    <button className="btn btn-link" onClick={e => this.routeChangeGet()}>Click Here</button>

                                    </h6>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <br /><br /><br /><br /><br /> <br />
            </div>
        )
    }
}
export default OrgRegistration;
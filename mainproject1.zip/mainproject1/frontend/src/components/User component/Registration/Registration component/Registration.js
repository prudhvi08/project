import React from 'react';
import images from '../images/down.png';
import { BrowserRouter as Router, Link } from 'react-router-dom';


class Registration extends React.Component {
    
    routeChangeLogin = (e) => {
        let path = `/Login`;
        this.props.history.push(path);
    }

    routeChangeHome = (e) => {
        let path = `/`;
        this.props.history.push(path);
    }

    render() {
        return (
            <div style={{ backgroundColor: "brown" }}>
                <br /><br /><br /><br /><br /><br />
                <div className="row justify-content-lg-center">
                    <div className="col-lg-5">
                        <div className="card">
                            <div className="card-body">
                                <center>
                                    <img src={images} width="140px" height="100px" />
                                </center>
                                <h3 align="center">Register Here</h3>
                                <br />
                                <form align="center" >
                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <input type="email" className="form-control text-center"
                                                    placeholder="Enter Email " />
                                            </div>
                                        </div>
                                    </div>

                                    <div className=" row justify-content-lg-center">
                                        <div className="col-lg-8">
                                            <div className="form-group">
                                                <input type="text" className="form-control text-center"
                                                    placeholder="Enter Name" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">

                                            <div className="form-group">
                                                <input type="number" className="form-control text-center"
                                                    placeholder="Enter Phone Number" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">


                                            <div className="form-group">
                                                <input type="number" className="form-control text-center"
                                                    placeholder="Enter Date Of Birth" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row justify-content-lg-center">
                                        <div className="col-lg-8">

                                            <div className="form-group">
                                                <input type="password" className="form-control text-center" placeholder="Enter Password" />
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <input type="submit" value="Sign in" onClick={e => this.routeChangeLogin()} className="btn btn-primary" />&nbsp;
                                        <input type="submit" value="Go Back to Home" onClick={e => this.routeChangeHome()} className="btn btn-success" />

                                    </div>
                                    <h6>Already a user?&nbsp;
                                <button className="btn btn-link" onClick={e => this.routeChangeLogin()}> Click here</button>
                                    </h6>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <br /><br /><br /><br /><br /> <br />
            </div>
        )
    }
}
export default Registration;
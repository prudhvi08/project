import React from 'react';
import styled from 'styled-components';
import {Link} from 'react-router-dom';
 function NotificationData(props) {
   
    const PromotedStyles = styled.div`
    width: 550px;
    border: 1px solid #CACCCE;
    padding: 5px;
    margin: 0 15px;
    background-color: skyblue;
    box-shadow: -5px 5px #D0D3D6;
   
    h1 {
      float: left;
      margin 15px 15px;
      color: #CACCCE;
    }

        // .topright {
        //     position: absolute;
        //     top: 8px;
        //     right: 16px;
        //     font-size: 18px;
        //   }
  
  `;
    return (
        <PromotedStyles className='promoted'>
            <div>
                <div >
               
                    <img width="100px" src={props.noti.imageUrl} />
                    
                    <span className="MyLinkText">
                        {props.noti.text}
                    </span><button className="btn btn-success btn-sm" align="right" >X</button> &nbsp;
                  
                     <button className="btn btn-success btn-sm"  ><Link to='/header'>View Jobs</Link></button> 
                </div>
            </div>
        </PromotedStyles>
    )
}

export default NotificationData
import React from 'react';
// import { FontAwesomeIcon } from '@fontawesome/react-fontawesome';

export class ViewJobs extends React.Component {
    render() {
        return (
            <div className="container" style={{ boxshadow: '10px 10px 10px' }}>
                <div className="row">
                    <div className="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                        <img className="img" height="100px" width="100%" src={require("./pic2.png")} />
                    </div>
                    <div className="row" style={{ margin: '50px' }}>
                        <div className="col-md-4 col-sm-4 col-xs-12 col-lg-4">
                            <div className="row">
                                <div className="col-md-12 col-md-12-sm-12 col-xs-12 col-lg-12" style={{left: '110px' }}>
                                    {/* <div><FontAwesomeIcon icon="envelope" /></div> */}
                                    {/* <div>Profile Name</div> */}
                                </div>
<br/>
<br/><br/>
<br/><br/>
<br/><br/>
<br/><br/>

                                <div className="col-md-12 col-md-12-sm-12 col-xs-12 col-lg-12" style={{ top: '-120px' }}>
                                   
                                    <img className="img" height="200px" width="70%" src={require("./pic1.jpg")} />
                                   
 
                                    <h4>Bussines Analyst</h4>

                                    <h3><a data-control-name="company_link" href="/company/1426/life/" 
                                    id="ember551" class="jobs-top-card__company-url ember-view">Barclays</a></h3>
                                    <p>, Chennai, TamilNadu, India</p>
                                        {/* <body> */}
                                        <h6 onload="showDateTime()">Date</h6>
                                   
                                    {/* <p>Capgemini</p> */}
                                    <button className="btn btn-info req-btn" >Apply Job</button>
                             
                                {/* <div className="row user-detail-row">
                                    <div className="col-md-12 col-sm-12 col-lg-12">
                                        <div className="border"></div>
                                        <p>FOLLOWERS</p>
                                        <span style={{ color: '#7CBBC3' }}>320</span>
                                        <div className="border"></div>
                                        <p>FOLLOWING</p>
                                        <span style={{ color: '#7CBBC3' }}>147</span>
                                    </div>
                                </div> */}
                                 
                                    <div className="row user-detail-row">
                                    <div className="col-md-12 col-sm-12 col-lg-12">
                                    <div className="col-md-6">
                                    <h4 >
                                        Required
                                    </h4>
                                    <ul>
                                        <li>Knowledge on Python </li>
                                        <li>Unix,Linux </li>
                                        <li> Core Java </li>
                                    </ul>

 
                                    </div>


                                    <h4 >
                                        Skills 
                                    </h4>
                                    <ul>
                                        <li>C language </li>
                                        <li>C ++ </li>
                                        <li> Core Java </li>
                                        <li> Python </li>
                                        
                                    </ul>
                                    </div>
                                    </div>
                                    </div>
                            </div>
                        </div>
                        <div className="col-md-8 col-sm-8 col-xs-12 col-lg-8">
                            <div className="col-md-12 col-sm-12 col-xs-12 col-lg-12">
                                <h1>Job Description</h1>
                                <br/>
                                <h3>Help us build the bank of Tomorrow</h3>
                                <br/>
                                <p>Everything we do at Barclays starts and ends with helping people to move forward in their lives. Like one of our mortgage products guiding a first time buyer onto the property ladder or our Digital Wings programme which helps people develop the confidence to progress in the digital age. Whether it’s supporting small businesses or preparing young adults with the key skills needed for work, everything we do helps our communities and customers prepare for their future and embrace it.</p>
                                <img src={require('./img1.jpg' ) } />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ViewJobs;